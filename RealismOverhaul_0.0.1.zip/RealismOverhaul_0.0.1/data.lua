-- data.lua

-- ITEMS
require("prototypes.items.intermediate-product-items")

-- RECIPES
require("prototypes.recipes.intermediate-product-recipes")

-- TECH
require("prototypes.technology")